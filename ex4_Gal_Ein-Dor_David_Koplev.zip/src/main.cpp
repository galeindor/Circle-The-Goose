
#include "GameController.h"

int main()
{
	auto game = GameController();
	game.run();
}
